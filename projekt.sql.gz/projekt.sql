-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: java_projekt
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `City`
--

DROP TABLE IF EXISTS `City`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `City` (
  `Zip_code` varchar(10) NOT NULL,
  `City_name` varchar(100) NOT NULL,
  `Country` int NOT NULL,
  PRIMARY KEY (`Zip_code`),
  KEY `fk_city_country` (`Country`),
  CONSTRAINT `fk_city_country` FOREIGN KEY (`Country`) REFERENCES `Country` (`UID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `City`
--

LOCK TABLES `City` WRITE;
/*!40000 ALTER TABLE `City` DISABLE KEYS */;
/*!40000 ALTER TABLE `City` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Country` (
  `UID` int NOT NULL AUTO_INCREMENT,
  `Country_Name` varchar(100) NOT NULL,
  `VAT` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `Country_Name` (`Country_Name`),
  CONSTRAINT `Country_chk_1` CHECK ((`VAT` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Football_Club`
--

DROP TABLE IF EXISTS `Football_Club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Football_Club` (
  `Club_UID` int NOT NULL AUTO_INCREMENT,
  `Club_name` varchar(150) NOT NULL,
  `City` varchar(10) DEFAULT NULL,
  `Total_players` int DEFAULT '0',
  PRIMARY KEY (`Club_UID`),
  UNIQUE KEY `Club_name` (`Club_name`),
  KEY `fk_club_city` (`City`),
  CONSTRAINT `fk_club_city` FOREIGN KEY (`City`) REFERENCES `City` (`Zip_code`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Football_Club_chk_1` CHECK ((`Total_players` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Football_Club`
--

LOCK TABLES `Football_Club` WRITE;
/*!40000 ALTER TABLE `Football_Club` DISABLE KEYS */;
/*!40000 ALTER TABLE `Football_Club` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Match`
--

DROP TABLE IF EXISTS `Match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Match` (
  `Match_UID` int NOT NULL AUTO_INCREMENT,
  `Match_datetime` datetime NOT NULL,
  `Stadium` int NOT NULL,
  `Tickets_left` int DEFAULT '0',
  PRIMARY KEY (`Match_UID`),
  KEY `fk_match_stadium` (`Stadium`),
  CONSTRAINT `fk_match_stadium` FOREIGN KEY (`Stadium`) REFERENCES `Stadium` (`UID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Match_chk_1` CHECK ((`Tickets_left` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Match`
--

LOCK TABLES `Match` WRITE;
/*!40000 ALTER TABLE `Match` DISABLE KEYS */;
/*!40000 ALTER TABLE `Match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Match_competitors`
--

DROP TABLE IF EXISTS `Match_competitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Match_competitors` (
  `Match_ID` int NOT NULL,
  `Club_ID` int NOT NULL,
  PRIMARY KEY (`Match_ID`,`Club_ID`),
  KEY `fk_mc_club` (`Club_ID`),
  CONSTRAINT `fk_mc_club` FOREIGN KEY (`Club_ID`) REFERENCES `Football_Club` (`Club_UID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mc_match` FOREIGN KEY (`Match_ID`) REFERENCES `Match` (`Match_UID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Match_competitors`
--

LOCK TABLES `Match_competitors` WRITE;
/*!40000 ALTER TABLE `Match_competitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `Match_competitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Session`
--

DROP TABLE IF EXISTS `Session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Session` (
  `Session_ID` char(36) NOT NULL,
  `User_ID` int NOT NULL,
  `Session_type` enum('Login','Purchase','Admin','Guest') DEFAULT 'Login',
  `Session_data` json DEFAULT NULL,
  PRIMARY KEY (`Session_ID`),
  KEY `fk_session_user` (`User_ID`),
  CONSTRAINT `fk_session_user` FOREIGN KEY (`User_ID`) REFERENCES `User` (`UID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Session`
--

LOCK TABLES `Session` WRITE;
/*!40000 ALTER TABLE `Session` DISABLE KEYS */;
/*!40000 ALTER TABLE `Session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Stadium`
--

DROP TABLE IF EXISTS `Stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stadium` (
  `UID` int NOT NULL AUTO_INCREMENT,
  `Stadium_name` varchar(150) NOT NULL,
  `Number_of_seats` int NOT NULL,
  `City` varchar(10) NOT NULL,
  PRIMARY KEY (`UID`),
  KEY `fk_stadium_city` (`City`),
  CONSTRAINT `fk_stadium_city` FOREIGN KEY (`City`) REFERENCES `City` (`Zip_code`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Stadium_chk_1` CHECK ((`Number_of_seats` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stadium`
--

LOCK TABLES `Stadium` WRITE;
/*!40000 ALTER TABLE `Stadium` DISABLE KEYS */;
/*!40000 ALTER TABLE `Stadium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `UID` int NOT NULL AUTO_INCREMENT,
  `Paypal_ID` varchar(100) DEFAULT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password_hash` char(64) NOT NULL,
  `Full_name` varchar(150) DEFAULT NULL,
  `PIN` char(6) DEFAULT NULL,
  `Authorization_level` enum('User','Admin','SuperAdmin') DEFAULT 'User',
  `Creation_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Country` int DEFAULT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`),
  KEY `fk_user_country` (`Country`),
  CONSTRAINT `fk_user_country` FOREIGN KEY (`Country`) REFERENCES `Country` (`UID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-27 14:21:01
